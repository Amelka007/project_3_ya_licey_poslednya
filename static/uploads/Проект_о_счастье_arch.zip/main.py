import os
import pygame
pygame.init()
size = width, height = 700, 700
screen = pygame.display.set_mode(size)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname)
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image

all_sprites = pygame.sprite.Group()
cur = load_image('name.png', -1)
sprite = pygame.sprite.Sprite(all_sprites)
sprite.image = cur
sprite.rect = sprite.image.get_rect()
print(sprite.rect)
pygame.mouse.set_visible(False)
#это мышку вырубает

running = True
while running:
    for event in pygame.event.get():
    #обработка событий
        if event.type == pygame.QUIT:
            running = False
        #чтобы экран закрылся
        if event.type == pygame.MOUSEMOTION:
            sprite.rect.topleft = event.pos
        #сохранение коров мышки если она двигается
    screen.fill(pygame.Color("black"))
    if pygame.mouse.get_focused():
        all_sprites.draw(screen)
    pygame.display.flip()
pygame.quit()
